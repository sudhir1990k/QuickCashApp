function ShowDetails(value) {
        alert("doing my job");
        location.href = "index.html";
}
